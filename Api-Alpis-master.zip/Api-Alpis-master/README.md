

<p align="center">
<img src="https://avatars.githubusercontent.com/AlipBot" width="200" height="200"/>
</p>
<p align="center">
  <a href="#"><img src="http://readme-typing-svg.herokuapp.com?color=d1fa02&center=true&vCenter=true&multiline=false&lines=Welcome+To+Rest+Api+Alpis+" alt="">
</p>
<p align="center">
<a href="#"><img title="Creator" src="https://img.shields.io/badge/Creator-AlipBot-red.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://github.com/AlipBot?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/AlipBot?color=green&style=flat-square"></a>
<a href="https://github.com/AlipBot/Api-Alpis/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/AlipBot/Api-Alpis?color=white&style=flat-square"></a>
<a href="https://github.com/AlipBot/Api-Alpis/network/members"><img title="Forks" src="https://img.shields.io/github/forks/AlipBot/Api-Alpis?color=yellow&style=flat-square"></a>
<a href="https://github.com/AlipBot/Api-Alpis/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/AlipBot/Api-Alpis?label=Watchers&color=red&style=flat-square"></a>
<a href="https://github.com/AlipBot/Api-Alpis"><img title="Open Source" src="https://badges.frapsoft.com/os/v2/open-source.svg?v=103"></a>
<a href="https://github.com/AlipBot/Api-Alpis/"><img title="Size" src="https://img.shields.io/github/repo-size/AlipBot/Api-Alpis?style=flat-square&color=darkred"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FAlipBot%2FApi-Alpis%2Fhit-counter&count_bg=%2379C83D&title_bg=%23555555&icon=probot.svg&icon_color=%2304FF00&title=hits&edge_flat=false"/></a>
<a href="https://github.com/AlipBot/Api-Alpis/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained-No-red.svg"></a>&nbsp;&nbsp;
</p>

* ## TUTORIAL 📌


* ## PACTH HEROKU NEXT UPDATE AKAN DATANG YA GUYS

Forks Github Ini
 [`Klik Sini Untuk Fork Project`](https://github.com/AlipBot/api-alpis/fork)<br>

DEPLOY TO HEROKU

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/)

CONNECT HEROKU TO GITHUB DAN
CONNECT PROJECTS GITHUB YANG KALIAN FORK TADI
LALU TEKAN
Deploy

<a href="https://youtu.be/QZ2FWTur9WA"><img src="https://img.youtube.com/vi/QZ2FWTur9WA/sddefault.jpg" alt="">
 [`Tutorial In Youtube`](https://youtu.be/QZ2FWTur9WA)<br>

* # ``Cara On 24 Jam``

[`Klik Sini`](https://kaffeine.herokuapp.com)<br>
add website kamu

* ## SETTING ⚙️
File Setting ``setting.js``

[`Tukar Nama Creator Disini`](https://github.com/AlipBot/Api-Alpis/blob/master/settings.js#:~:text=creator%20%3D%20%27-,%E4%B9%82%F0%9D%98%BC%F0%9D%99%A1%F0%9D%99%9E%F0%9D%99%A5%E4%B9%82,-%27)<br>

* ## FEATURE LIST 💡

| FEATURE |🌱|
| ------------- | ------------- |
| Dowloader |✔️|
| Text Pro  |✔️|
| Photooxy  |✔️|
| Sound Of Text  |✔️|
| Search  |✔️|
| Random Gambar  |✔️|
| Game  |✔️|
| Maker |✔️|
| Link Short  |✔️|
| Information |✔️|
| Emoji  |✔️|
| Tools  |✔️|
| Islamic  |✔️|

<img src="https://telegra.ph/file/1cbc7e659b35a053bf25f.png" width="150" height="150">

``Halal Rest API``

## ``Credit 💳 Script``

<img src="https://avatars.githubusercontent.com/AlipBot" width="200" height="200">

[`AlipBot`](https://github.com/AlipBot)<br>
